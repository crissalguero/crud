<h2>Editar Usuario</h2>

<form action="/user/update/<?= $user['id'] ?>" method="post">
    <label for="name">Nombre:</label>
    <input type="text" name="name" value="<?= $user['name'] ?>" required><br><br>
    <label for="email">Email:</label>
    <input type="email" name="email" value="<?= $user['email'] ?>" required><br><br>
    <input type="submit" value="Actualizar">
</form>
<a href="/user">Volver</a>
