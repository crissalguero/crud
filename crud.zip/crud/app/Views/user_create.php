<h2>Agregar Nuevo Usuario</h2>

<form action="/user/store" method="post">
    <label for="name">Nombre:</label>
    <input type="text" name="name" required><br><br>
    <label for="email">Email:</label>
    <input type="email" name="email" required><br><br>
    <input type="submit" value="Guardar">
</form>
<a href="/user">Volver</a>
