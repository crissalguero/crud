<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'Home::index');
$routes->get('/user', 'User::index'); // Leer usuarios
$routes->get('/user/create', 'User::create'); // Formulario de creación
$routes->post('/user/store', 'User::store'); // Guardar nuevo usuario
$routes->get('/user/edit/(:num)', 'User::edit/$1'); // Formulario de edición
$routes->post('/user/update/(:num)', 'User::update/$1'); // Actualizar usuario
$routes->get('/user/delete/(:num)', 'User::delete/$1'); // Eliminar usuario

