<?php

namespace App\Controllers;
use App\Models\UserModel;
use CodeIgniter\Controller;

class User extends Controller {

    // Mostrar todos los usuarios (READ)
    public function index() {
        $model = new UserModel();
        $data['users'] = $model->findAll();
        return view('user_list', $data);
    }

    // Mostrar formulario para crear un nuevo usuario (CREATE)
    public function create() {
        return view('user_create');
    }

    // Guardar un nuevo usuario en la base de datos (CREATE)
    public function store() {
        $model = new UserModel();
        $data = [
            'name' => $this->request->getPost('name'),
            'email' => $this->request->getPost('email')
        ];
        $model->insert($data);
        return redirect()->to('/user');
    }

    // Mostrar formulario para editar un usuario existente (UPDATE)
    public function edit($id = null) {
        $model = new UserModel();
        $data['user'] = $model->find($id);
        return view('user_edit', $data);
    }

    // Actualizar un usuario en la base de datos (UPDATE)
    public function update($id = null) {
        $model = new UserModel();
        $data = [
            'name' => $this->request->getPost('name'),
            'email' => $this->request->getPost('email')
        ];
        $model->update($id, $data);
        return redirect()->to('/user');
    }

    // Eliminar un usuario (DELETE)
    public function delete($id = null) {
        $model = new UserModel();
        $model->delete($id);
        return redirect()->to('/user');
    }
}
